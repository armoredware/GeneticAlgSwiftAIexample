//: Playground - noun: a place where people can play

import UIKit



class Gene{
    var name:String
    var value:Double
    var weight:Double
    var volume:Double
    
    init(name:String, value:Double, weight:Double, volume:Double){
        self.name = name
        self.value = value
        self.weight = weight
        self.volume = volume
    }
    
}

class Fitness{
    
    var totalWeight: Double
    var totalVolume: Double
    var totalValue: Double
    
    init(totalWeight: Double, totalVolume: Double, totalValue: Double){
        self.totalWeight = totalWeight
        self.totalVolume = totalVolume
        self.totalValue = totalValue
    }
    
    func isGreater(other:Fitness)-> Bool{
        if self.totalValue != other.totalValue{
            return self.totalValue > other.totalValue
        }
        if self.totalWeight != other.totalWeight{
            return self.totalWeight > other.totalWeight
        }
        return self.totalValue < other.totalValue
    }
    
    func fitString()-> String{
        return "weight: \(self.totalWeight) volume: \(self.totalVolume) value: \(self.totalValue)"
    }
}


class Chromosome{
    var Genes:[GeneBatch]
    var Fitness:Fitness
    var Age:Int
    init(genes:[GeneBatch], fitness:Fitness){
        self.Genes = genes
        self.Fitness = fitness
        self.Age = 0
    }
}

class GeneBatch{
    
    var gene:Gene
    var quantity:Double
    
    init(gene:Gene,quantity:Double){
        self.gene = gene
        self.quantity = quantity
    }
    
    func equal(other:GeneBatch) ->Bool{
        if (self.gene.name == other.gene.name && self.quantity == other.quantity){
            return true
        }
        else{
            return false
        }
    }
}

//Global Variables
var startTime = Date().timeIntervalSince1970
var geneCandidates:[GeneBatch]? = []

let maxWeight = 10.0
let maxVolume = 4.0
var optimalGeneBatch: [GeneBatch] = []
var optimalFitness: Fitness?

var improvementArray:[Chromosome]? = []
var bestParent: Chromosome?



let flour = Gene(name:"Flour",value:1680,weight:0.265,volume:0.41)
let butter = Gene(name:"Butter",value:1440,weight:0.5,volume:0.13)
let sugar = Gene(name:"Sugar",value:1840,weight:0.441,volume:0.29)


func bisectLeft(array: Array<Fitness>, x:Double)->Int{
    print("Running function BiSect Left")
    var i = 0
    while ( i < array.count) {
        
        if (array[i].totalValue >= Double(x)){
        return i
        }
        i = i + 1
    }
    return array.count
}


func bisectRight(array: Array<Fitness>, x:Double)->Int{
    print("Running function BiSect Right")
    var i = 0
    while ( i < array.count) {
        
        if (array[i].totalValue > Double(x)) {
            return i
        }
        i = i + 1
    }
    return array.count
}


func maxQuantity(gene: Gene , maxWeight: Double, maxVolume: Double) -> Int{
    return min(Int(maxWeight / gene.weight), Int(maxVolume / gene.volume))
}





/*
class Benchmark:
@staticmethod
def run(function):
timings = []
stdout = sys.stdout
for i in range(100):
sys.stdout = None
startTime = time.time()
function()
seconds = time.time() - startTime
sys.stdout = stdout
timings.append(seconds)
mean = statistics.mean(timings)
if i < 10 or i % 10 == 9:
print("{} {:3.2f} {:3.2f}".format(
1 + i, mean,
statistics.stdev(timings, mean) if i > 1 else 0))
*/



//provides a random Sample from our set of genes
func randSample(origSet:[GeneBatch], sampSize:Int) -> [GeneBatch]{
    print("Running randSample function")
    var randomIndex: UInt32 = 0
    var uniqSet: [GeneBatch] = origSet
    var rSample = [] as [GeneBatch]
    
    while rSample.count < sampSize{
        randomIndex = arc4random_uniform(UInt32(uniqSet.count))
        rSample.append(uniqSet[Int(randomIndex)])
        uniqSet.remove(at: Int(randomIndex))
    }
    
    return rSample
}


//score the guess against the target
func getFitness(genes:[GeneBatch])-> Fitness{
    print("Running function Get Fitness")
    
    var totalWeight:Double = 0.0
    var totalVolume:Double = 0.0
    var totalValue:Double = 0.0
    //var count = 0
    
    for quantity in genes{
        let count = quantity.quantity
        //count = gene.quantity
        totalWeight += quantity.gene.weight * count
        totalVolume += quantity.gene.volume * count
        totalValue += quantity.gene.value * count
    }
    let fitness = Fitness(totalWeight:totalWeight, totalVolume:totalVolume, totalValue:totalValue)
    return fitness
}


func addGeneBatch(genes:[GeneBatch], geneCandidates:[GeneBatch], maxWeight:Double, maxVolume:Double) -> GeneBatch? {
    print("Running function add Gene Batch")
    var usedGenes: [GeneBatch]

    usedGenes = genes

    var randIdx = Int(arc4random_uniform(UInt32(genes.count)))
    var randGene = geneCandidates[randIdx].gene
   for gene in usedGenes{
    if (randGene.name == gene.gene.name){
         randIdx = Int(arc4random_uniform(UInt32(genes.count)))
         randGene = genes[randIdx].gene
        }
    }
    let maxQuant = maxQuantity(gene: randGene, maxWeight: maxWeight, maxVolume: maxVolume)
    print("Max Quantity",maxQuant)
    if maxQuant > 0{
        return GeneBatch(gene: randGene, quantity: Double(maxQuant))
    }else{
        return nil
    }
}

func createGeneBatchArray(geneCandidates:[GeneBatch], maxWeight:Double, maxVolume:Double)->[GeneBatch]{
    print("Running function create Gene Batch Array")
    print(geneCandidates[0].gene.name)
    print("Num of Gene Candidates: ", geneCandidates.count)
    var genes: [GeneBatch] = []
    var remainingWeight = maxWeight
    var remainingVolume = maxVolume
    
    var randRange = Int(arc4random_uniform(UInt32(geneCandidates.count)))
    print("Random Range: ", randRange)
    if randRange == 0{
        randRange = 1
    }
    for _ in 1...randRange{
        print("in loop")
        let newGene = addGeneBatch(genes:genes, geneCandidates:geneCandidates, maxWeight:remainingWeight, maxVolume:remainingVolume)
        if newGene != nil{
            genes.append(newGene!)
            remainingWeight -= newGene!.quantity * newGene!.gene.weight
            remainingVolume -= newGene!.quantity * newGene!.gene.volume
        }
    }
return genes
    
}

func mutate(genes: inout Chromosome, geneCandidates:[GeneBatch], maxWeight:Double, maxVolume:Double)-> Chromosome{
    print("Running function Mutate")
    let randIntRemoving = Int(arc4random_uniform(UInt32(10)))
    let randIntAdding = Int(arc4random_uniform(UInt32(100)))
    let randIntChanging = Int(arc4random_uniform(UInt32(4)))
    let fitness = getFitness(genes:genes.Genes)
    var remainingWeight = maxWeight - fitness.totalWeight
    var remainingVolume = maxVolume - fitness.totalVolume
    
    //removing gene
    if genes.Genes.count > 1 && randIntRemoving == 1 {
        let randIdx = Int(arc4random_uniform(UInt32(genes.Genes.count)))
        let geneBatch = genes.Genes[randIdx]
        let gene = geneBatch.gene
        remainingWeight += gene.weight * geneBatch.quantity
        remainingVolume += gene.volume * geneBatch.quantity
        genes.Genes.remove(at:randIdx)
    }
    
    //adding gene
    if (remainingWeight > 0 || remainingVolume > 0) && genes.Genes.count == 0 || genes.Genes.count < geneCandidates.count && randIntAdding == 1{
        let newGene = addGeneBatch(genes: genes.Genes, geneCandidates: geneCandidates, maxWeight: remainingWeight, maxVolume: remainingVolume)
        if newGene != nil{
            genes.Genes.append(newGene!)
        }
    }
    //geneCandidate replacement random item already in GeneBatch array
    let randIdx = Int(arc4random_uniform(UInt32(genes.Genes.count)))
    let geneBatch = genes.Genes[randIdx]
    var gene = geneBatch.gene
    remainingWeight += gene.weight * geneBatch.quantity
    remainingVolume += gene.volume * geneBatch.quantity
    
    if genes.Genes.count < geneCandidates.count && randIntChanging == 1{
        var geneAB = randSample(origSet: geneCandidates, sampSize: 2)
        if geneAB[0].gene.name != gene.name{
            gene = geneAB[0].gene
        }
        else {
            gene = geneAB[1].gene
        }
    }
    
    let maxQuant = maxQuantity(gene: gene, maxWeight: remainingWeight, maxVolume: remainingVolume)
    if maxQuant > 0{
        let randQuant = Int(arc4random_uniform(UInt32(maxQuant)))
        genes.Genes[randIdx] = GeneBatch(gene:gene, quantity:Double(randQuant))
    }
    else{
        genes.Genes.remove(at: randIdx)
    }
    return genes
}
    
func display(geneCandidates:[GeneBatch], startTime: Double){
    print("Running function Display")
        let newTime = Date().timeIntervalSince1970
        let timer = Double(newTime) - Double(startTime)
        
        let genes = geneCandidates
        let fitness = getFitness(genes:genes)
        //Think we need to make [GeneBatch] chromosomes
        for gene in genes{
        print("Name:",gene.gene.name, " x ",gene.quantity, " Fitness: ",fitness.totalValue, "Time: ",timer)
     }
}

func testGene(){
    
}

func fillSack(geneCandidates:[GeneBatch], maxWeight:Double, maxVolume:Double, optimalFitness: inout Fitness){
    print("Running function FillSack")
    let startTime = Date().timeIntervalSince1970
    var assertTrue: Bool = false
    display(geneCandidates:geneCandidates , startTime: startTime)
    let fitness = getFitness(genes: geneCandidates)
    let genes = createGeneBatchArray(geneCandidates: geneCandidates, maxWeight: maxWeight, maxVolume: maxVolume)
    var childGenes = Chromosome(genes:genes, fitness:getFitness(genes: geneCandidates))
    var child = mutate(genes: &childGenes, geneCandidates: geneCandidates, maxWeight: maxWeight, maxVolume: maxVolume)
    
    //added random Target Length
    //let randLength = Double(arc4random_uniform(UInt32(geneCandidates.count)))
    
    let best = getBest(getFitness: fitness, targetLen: 3, optimalFitness: &optimalFitness, geneSet: geneCandidates, customMutate: childGenes, customCreate: nil, maxAge: 50)
    
    if optimalFitness.isGreater(other:best.Fitness){
        assertTrue = true
        
    }

    if assertTrue == true{
        print("Sack filled, reached optimal Fitness")
        //display(geneCandidates: genes, startTime: startTime)
    }
    
}


func getBest(getFitness:Fitness, targetLen:Double?, optimalFitness: inout Fitness, geneSet:[GeneBatch],
             customMutate:Chromosome?, customCreate:Chromosome?, maxAge:Int) -> Chromosome{
    print("Running function GetBest")
    var genesParent = Chromosome(genes: geneCandidates!, fitness: optimalFitness)
    var mutate = Chromosome(genes: geneCandidates!, fitness: optimalFitness)
    
    
    
    if customMutate == nil{
         mutate = genMutation(parent: customMutate!, geneSet: geneCandidates!, fitness: getFitness)
            //return mutate
    }
    else{
        print("else")
        //mutate = genMutation(parent: customMutate!, geneSet: geneCandidates!, fitness: getFitness)
         mutate = genMutateCustom(parent: customMutate!)
            //return custMutate
    }
    
    if customCreate == nil{
         genesParent = genParent(length: Int(targetLen!), geneSet: geneSet, fitness: getFitness)
            //return genes
    }
    else{
        //genesParent = genParent(length: Int(targetLen!), geneSet: geneSet, fitness: getFitness)
         genesParent = customCreate!
        //return Chromosome(genes: genes, fitness: getFitness(genes))
        //return genes!
    }
    
    display(geneCandidates:mutate.Genes, startTime:startTime)
  
    for improvement in getImprovement(newChild:mutate, inParent: &genesParent, maxAge:maxAge){
        print("For loop improvement")
        display(geneCandidates:improvement.Genes, startTime:startTime)
        
        if optimalFitness.isGreater(other: improvement.Fitness){
            return improvement
        }
    }
    return mutate
    
}
//Generate Parent Function New
func genParent(length:Int, geneSet: [GeneBatch], fitness:Fitness) -> Chromosome{
    print("Running function Gen Parent")
    var genes = [] as [GeneBatch]
    var sampleSize = 0
    var fitness: Fitness = getFitness(genes:genes)
    
    while genes.count < length{
        sampleSize = min(length - genes.count, geneSet.count)
        genes = randSample(origSet:geneSet, sampSize:sampleSize);
        fitness = getFitness(genes:genes)
    }
    return Chromosome(genes:genes, fitness:fitness)
    
}

func genMutation(parent:Chromosome, geneSet:[GeneBatch], fitness:Fitness?)->Chromosome{
    print("Running function Gen Mutation")
    var randIdx: UInt32 = 0
    var childGenes = parent.Genes
    randIdx = arc4random_uniform(UInt32(parent.Genes.count))
    var newGene = randSample(origSet:geneSet, sampSize:2)
    var alternate = randSample(origSet:geneSet, sampSize:2)
    
    if newGene[0].gene.name == childGenes[Int(randIdx)].gene.name{
        childGenes[Int(randIdx)] = alternate[1]
    }
    else{
        childGenes[Int(randIdx)] = newGene[0]
    }
    let fitness = getFitness(genes:childGenes)
    print("Child: ",childGenes[0].gene.name, childGenes[1].gene.name)
    return Chromosome(genes:childGenes, fitness:fitness)
}

//generate mutation custom
func genMutateCustom(parent:Chromosome)->Chromosome{
    print("Running function Gen Mutate Custom")
    let childGenes = parent.Genes
    //custom_mutate(childGenes)
    let fitness = getFitness(genes:childGenes)
    return Chromosome(genes:childGenes, fitness:fitness)
}

func getImprovement(newChild: Chromosome, inParent: inout Chromosome, maxAge:Int)->[Chromosome]{
    print("Running function Get Improvement")
    var parent: Chromosome
    parent = genParent(length: 3, geneSet: geneCandidates!, fitness: optimalFitness!)
    
    if inParent.Fitness.isGreater(other: parent.Fitness){
        parent = inParent
    }
    if parent.Fitness.isGreater(other: bestParent!.Fitness){
    bestParent! = parent
    improvementArray!.append(bestParent!)
    }
    var historicalFitnesses = [bestParent!.Fitness]
    var proportionSimilar:Double?
    var onOff = false
    //impLoop: while onOff == false {
    impLoop: while (optimalFitness!.isGreater(other: bestParent!.Fitness)) {
        print("IMPROVEMENT LOOP")
        var child = mutate(genes: &parent, geneCandidates: geneCandidates!, maxWeight: maxWeight, maxVolume: maxVolume)
        child = genMutation(parent: bestParent!, geneSet: geneCandidates!, fitness: optimalFitness!)
        if parent.Fitness.isGreater(other:child.Fitness){
            if maxAge == 0{
                //continue
                onOff = true
                //continue impLoop
            }
        parent.Age += 1
            if maxAge > parent.Age{
                //continue
                onOff = true
                //continue impLoop
                }
                
        //var index = bisectLeft(historicalFitnesses, child.Fitness ,0 ,historicalFitnesses.count)
        let index = bisectLeft(array:historicalFitnesses, x:child.Fitness.totalValue)
        let difference = historicalFitnesses.count - index
        proportionSimilar = Double(difference / historicalFitnesses.count)
        
            if Double(arc4random_uniform(UInt32(proportionSimilar! + 5))) < exp(proportionSimilar! * -1){
                parent = child
                //continue
                onOff = true
                //continue impLoop
            }
        bestParent!.Age = 0
        parent = bestParent!
        //continue
        onOff = true
            //continue impLoop
        }
        
        if parent.Fitness.isGreater(other:child.Fitness){
            //same fitness
            child.Age = parent.Age + 1
            parent = child
            //continue
            onOff = true
            //continue impLoop
        }
        child.Age = 0
        parent = child
        onOff = true
        //continue impLoop
   
        if child.Fitness.isGreater(other:bestParent!.Fitness){
                bestParent = child
                //yield bestParent
                improvementArray!.append(bestParent!)
                historicalFitnesses.append(bestParent!.Fitness)
                //return improvementArray!
        }
        print("Best Parent Fitness:", bestParent!.Fitness.totalValue)
        print("Parent Fitness:", parent.Fitness.totalValue)
        print("Child Fitness:", child.Fitness.totalValue)
    }
    return improvementArray!
}



//Main Test Function

print("Starting Test Gene")
//var geneCandidates: [GeneBatch] = []

//Gene Candidates
geneCandidates!.append(GeneBatch(gene:flour, quantity:1))
geneCandidates!.append(GeneBatch(gene:butter, quantity:1))
geneCandidates!.append(GeneBatch(gene:sugar, quantity:1))


//Optimal Gene Batch / Chromosome
optimalGeneBatch.append(GeneBatch(gene:flour,quantity:1))
optimalGeneBatch.append(GeneBatch(gene:butter,quantity:2))
optimalGeneBatch.append(GeneBatch(gene:sugar,quantity:2))


//Optimal Fitness
optimalFitness = getFitness(genes:optimalGeneBatch)
print("Optimal Fitness:",optimalFitness!.totalValue)



//set best with random a candidate
bestParent = genParent(length: 3, geneSet:geneCandidates!, fitness: optimalFitness!)

//Fill Sack
//fillSack(geneCandidates:geneCandidates!, maxWeight:maxWeight, maxVolume:maxVolume, optimalFitness:&optimalFitness!)


//Test Each Function

//Create Gene Batch Array has problem with quantity
var GBArry = createGeneBatchArray(geneCandidates: geneCandidates!, maxWeight: maxWeight, maxVolume: maxVolume)
print("GeneBatchArray",GBArry[0].gene.name, "Quantity: ", GBArry[0].quantity)


//Add Gene Batch
var addedGB = addGeneBatch(genes: GBArry, geneCandidates: geneCandidates!, maxWeight: maxWeight, maxVolume: maxVolume)
print("Add Gene Batch",addedGB!.gene.name, addedGB!.quantity)

//generate Parent
var mom = genParent(length: 3, geneSet: geneCandidates!, fitness: optimalFitness!)
print("Mom:", mom.Genes[0].gene.name, " ", mom.Genes[0].quantity, " ", mom.Fitness.totalValue)
print("Mom:", mom.Genes[1].gene.name, " ", mom.Genes[1].quantity, " ", mom.Fitness.totalValue)
print("Mom:", mom.Genes[2].gene.name, " ", mom.Genes[2].quantity, " ", mom.Fitness.totalValue)


//mutate Parent
mutate(genes: &mom, geneCandidates: geneCandidates!, maxWeight: maxWeight, maxVolume: maxVolume)
print("Baby:",mom.Genes[0].gene.name, " ", mom.Genes[0].quantity, " ", mom.Fitness.totalValue)
print("Baby:", mom.Genes[1].gene.name, " ", mom.Genes[1].quantity, " ", mom.Fitness.totalValue)
//print("Baby:", mom.Genes[2].gene.name, " ", mom.Genes[2].quantity, " ", mom.Fitness.totalValue)


//gen Mutate Custom
var baby = genMutateCustom(parent: mom)
print("Baby via Gen Mutation:", baby.Genes[0].gene.name, " ", baby.Genes[0].quantity, " ", baby.Fitness.totalValue)
print("Baby via Gen Mutation:", baby.Genes[1].gene.name, " ", baby.Genes[1].quantity, " ", baby.Fitness.totalValue)
//print("Baby via Gen Mutation:", baby.Genes[2].gene.name, " ", baby.Genes[2].quantity, " ", baby.Fitness.totalValue)


//gen Mutation
var bro = genMutation(parent: mom, geneSet: geneCandidates!, fitness: optimalFitness!)
print("Bro via Gen Mutation:", bro.Genes[0].gene.name, " ", bro.Genes[0].quantity, " ", bro.Fitness.totalValue)
print("Bro via Gen Mutation:", bro.Genes[1].gene.name, " ", bro.Genes[1].quantity, " ", bro.Fitness.totalValue)
//print("Bro via Gen Mutation:", bro.Genes[2].gene.name, " ", bro.Genes[2].quantity, " ", bro.Fitness.totalValue)

//get Improvement
/*var improve = getImprovement(newChild: baby, parent: &mom, maxAge: 1)
var improve2 = getImprovement(newChild: bro, parent: &mom, maxAge: 1)
print("Improvement for baby", improve[0].Fitness.totalValue)
print("Improvement for bro", improve2[0].Fitness.totalValue)*/


//get Fitness
var babyFitness = getFitness(genes: baby.Genes)


//get best
var best = getBest(getFitness: babyFitness, targetLen: 3.0, optimalFitness: &optimalFitness!, geneSet: geneCandidates!, customMutate: baby, customCreate: nil, maxAge: 5)
/*print("Improvmenet Best:",best.Genes[0].gene.name, best.Genes[0].quantity, best.Fitness.totalValue)
print("Improvement Best:",best.Genes[1].gene.name, best.Genes[1].quantity, best.Fitness.totalValue)
print("Improvement Best:",best.Genes[2].gene.name, best.Genes[2].quantity, best.Fitness.totalValue)*/
//print("FINAL BEST: ", bestParent!.Genes[0].gene.name, bestParent!.Genes[0].quantity, bestParent!.Fitness.totalValue)
//print("FINAL BEST: ", bestParent!.Genes[1].gene.name, bestParent!.Genes[1].quantity, bestParent!.Fitness.totalValue)
print("GeneLength:", bestParent!.Genes.count)
//print("Best:",best.Genes[2].gene.name, best.Genes[2].quantity, best.Fitness.totalValue)

var histCt = improvementArray!


for x in histCt{
    print ("History:", x.Fitness.totalValue)
    var gCt = x.Genes
    for y in gCt{
        print(y.gene.name, y.quantity )
    }
   
}

